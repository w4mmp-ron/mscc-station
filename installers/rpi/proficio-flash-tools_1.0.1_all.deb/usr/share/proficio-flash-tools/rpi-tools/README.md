# Pi / Linux flash tools (Black Pill)

Run on the Raspberry Pi (or any Linux PC). The firmware images come from `../release/`.

| Script | Burns | How | Needs |
|---|---|---|---|
| `flash-bootloader.sh` | `bootload-PA8.bin` @ `0x08000000` | ST-Link (SWD) | `sudo apt install stlink-tools` |
| `flash-bootloader.sh combined` | `boot-app-firmware.bin` @ `0x08000000` (bootloader + app, new board in one step) | ST-Link (SWD) | same |
| `flash-proficio.sh` | `app-firmware.bin` @ `0x08008000` (app only) | USB DFU, no ST-Link | `sudo apt install dfu-util` |

Same jobs as the Windows tools in `../release/` (`flash-bootloader.ps1` and `ProficioDfuDownloader.exe`).

## Install as a package (Pi)

```bash
sudo apt install ./proficio-flash-tools_1.0.1_all.deb   # pulls in stlink-tools + dfu-util
sudo proficio-flash-bootloader combined                  # = flash-bootloader.sh combined
sudo proficio-flash-app                                  # = flash-proficio.sh
```

The package carries the scripts and the firmware images from `release/` at build time
(`/usr/share/proficio-flash-tools/`). Build it with `bash build-deb.sh <version>` (WSL Debian
or the Pi); rebuild with a new version whenever the images in `release/` change.

## Use from the repo

```bash
cd proficio-stm32f411-25MHz/rpi-tools
sudo ./flash-bootloader.sh combined   # ST-Link wired to SWDIO/SWCLK/GND/3.3V
sudo ./flash-proficio.sh              # pill in DFU first: hold KEY (PA0), tap NRST, release KEY
```

`sudo` is only needed if your user can't open the USB device (no udev rule).
After a bootloader burn on a bare pill, the LED shows **C** (no codec), which is correct.
