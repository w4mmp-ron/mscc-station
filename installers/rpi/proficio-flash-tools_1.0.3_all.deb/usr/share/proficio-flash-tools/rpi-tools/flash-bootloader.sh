#!/bin/bash
# Burn the Black Pill bootloader (or bootloader + app) at 0x08000000 via ST-Link.
# Linux / Raspberry Pi version of flash-bootloader.ps1. Uses st-flash (stlink-tools).
#
# Usage:
#   ./flash-bootloader.sh              # bootload-PA8.bin (bootloader only)
#   ./flash-bootloader.sh combined     # boot-app-firmware.bin (bootloader + app)
#   ./flash-bootloader.sh <file.bin>   # any image at 0x08000000
#
# Needs: sudo apt install stlink-tools
# Run with sudo if the ST-Link isn't accessible to your user (no udev rule).
# App-only updates over USB DFU (no ST-Link): ./flash-proficio.sh

set -euo pipefail
BL_ADDR="0x08000000"
SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
IMG_DIR="$SCRIPT_DIR/../release"   # firmware images live in release/

case "${1:-}" in
  ""|bootload-PA8) FW="$IMG_DIR/bootload-PA8.bin" ;;
  combined)        FW="$IMG_DIR/boot-app-firmware.bin" ;;
  *)               FW="$1" ;;
esac

[[ -f "$FW" ]] || { echo "ERROR: missing $FW"; exit 1; }
command -v st-flash >/dev/null || {
  echo "ERROR: st-flash not found. sudo apt install stlink-tools"; exit 1; }

echo "Image   : $FW"
echo "Address : $BL_ADDR"
echo "Size    : $(stat -c %s "$FW") bytes"
echo

echo "=== Probe ST-Link / STM32F411 ==="
PROBE="$(st-info --probe 2>&1 || true)"
echo "$PROBE"
if echo "$PROBE" | grep -qi "Found 0 stlink"; then
  echo "ERROR: no ST-Link found. Check USB, or run with sudo."; exit 1
fi
if ! echo "$PROBE" | grep -qi "F4"; then
  echo "ERROR: no STM32F4 answering. Check SWDIO/SWCLK/GND/3.3V wiring and power."; exit 1
fi

echo
echo "=== Flash (write + verify + reset) ==="
st-flash --reset write "$FW" "$BL_ADDR"

echo
echo "OK: programmed at $BL_ADDR and verified."
echo "DFU: KEY+NRST (or PA8->GND+NRST with bootload-PA8). Remove PA8 jumper to run the app."
