#!/bin/bash
# Flash Proficio app at 0x08008000 (DFU must already be active).
# Usage: sudo ./flash-proficio.sh [app-firmware.bin]

set -euo pipefail
APP_ADDR="0x08008000"

[[ $# -le 1 ]] || {
  echo "Usage: $0 [app-firmware.bin]"
  echo "  KEY (PA0)+NRST → DFU, then run this."
  exit 1
}
FW="${1:-$(dirname "$(readlink -f "$0")")/../release/app-firmware.bin}"
[[ -f "$FW" ]] || { echo "ERROR: missing $FW"; exit 1; }
command -v dfu-util >/dev/null || { echo "ERROR: install dfu-util"; exit 1; }
dfu-util -l 2>/dev/null | grep -qi '0483:df11' || {
  echo "ERROR: no DFU device. KEY (PA0)+NRST first."; exit 1; }

echo "Flashing app: $FW → $APP_ADDR"
dfu-util -a 0 -s "${APP_ADDR}:leave" -D "$FW"
echo "Done. Reset without KEY to run app."
