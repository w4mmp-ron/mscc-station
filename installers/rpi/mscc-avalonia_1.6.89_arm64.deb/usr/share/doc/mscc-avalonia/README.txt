mscc-avalonia 1.6.89
================
MSCC Avalonia connect-only GUI for Multus / Proficio on Raspberry Pi OS 64-bit.

Install:
  sudo apt install -y ./mscc-avalonia_1.6.89_arm64.deb

Run:
  MSCC Start   (servers)
  MSCC Avalonia      (this client)  — or: mscc-avalonia

Settings (sticky):
  ~/.config/MSCC-Avalonia/mscc-avalonia.ini
  ~/.config/MSCC/mscc-favorites.ini

Does not start or stop ms-sdr; use MSCC Start / MSCC Stop.
